/* Login flow controller */

let currentPhone = '';
let pendingNewUser = false;

const steps = {
  phone: document.getElementById('step-phone'),
  otp: document.getElementById('step-otp'),
  newbuilder: document.getElementById('step-newbuilder'),
  notfound: document.getElementById('step-notfound'),
};

function showStep(name) {
  Object.values(steps).forEach(s => s.classList.add('hidden'));
  steps[name].classList.remove('hidden');
}

const urlParams = new URLSearchParams(window.location.search);
const signupIntent = urlParams.get('intent') === 'signup';
if (signupIntent) {
  document.querySelector('#step-phone p').textContent =
    'Enter a phone number to create a new builder account.';
}

/* --- Step 1: phone submit --- */
document.getElementById('phoneForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const raw = document.getElementById('phoneInput').value;
  const phone = normalizePhone(raw);
  if (phone.length !== 10) {
    toast('Enter a valid 10-digit phone number.', 'error');
    return;
  }
  currentPhone = phone;

  const existing = findUserByPhone(phone);
  if (!existing && !signupIntent) {
    showStep('notfound');
    return;
  }
  pendingNewUser = !existing;

  const btn = document.getElementById('sendOtpBtn');
  btn.disabled = true;
  btn.textContent = 'Sending…';
  setTimeout(() => {
    const code = generateOtp(phone);
    btn.disabled = false;
    btn.textContent = 'Send OTP';
    document.getElementById('phoneDisplay').textContent = '+91 ' + phone;
    const banner = document.getElementById('demoOtpBanner');
    banner.textContent = `Demo Mode (no SMS gateway connected): your OTP is ${code}`;
    banner.classList.add('show');
    showStep('otp');
    document.querySelector('.otp-box').focus();
    toast('OTP generated', 'success');
  }, 500);
});

/* --- OTP box behavior --- */
const otpBoxesEl = document.getElementById('otpBoxes');
otpBoxesEl.addEventListener('input', (e) => {
  const t = e.target;
  if (!t.classList.contains('otp-box')) return;
  t.value = t.value.replace(/\D/g, '');
  if (t.value && t.nextElementSibling) t.nextElementSibling.focus();
});
otpBoxesEl.addEventListener('keydown', (e) => {
  const t = e.target;
  if (!t.classList.contains('otp-box')) return;
  if (e.key === 'Backspace' && !t.value && t.previousElementSibling) {
    t.previousElementSibling.focus();
  }
});
otpBoxesEl.addEventListener('paste', (e) => {
  const text = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 4);
  if (!text) return;
  e.preventDefault();
  const boxes = [...document.querySelectorAll('.otp-box')];
  text.split('').forEach((ch, i) => { if (boxes[i]) boxes[i].value = ch; });
  (boxes[text.length - 1] || boxes[boxes.length - 1]).focus();
});

/* --- Step 2: OTP verify --- */
document.getElementById('otpForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const boxes = [...document.querySelectorAll('.otp-box')];
  const code = boxes.map(b => b.value).join('');
  if (code.length !== 4) {
    toast('Enter all 4 digits.', 'error');
    return;
  }
  const result = verifyOtp(currentPhone, code);
  if (!result.ok) {
    boxes.forEach(b => { b.classList.add('shake'); setTimeout(() => b.classList.remove('shake'), 400); });
    toast(result.reason, 'error');
    return;
  }

  if (pendingNewUser) {
    showStep('newbuilder');
    return;
  }

  const user = findUserByPhone(currentPhone);
  completeLogin(user);
});

document.getElementById('resendBtn').addEventListener('click', () => {
  const code = generateOtp(currentPhone);
  const banner = document.getElementById('demoOtpBanner');
  banner.textContent = `Demo Mode (no SMS gateway connected): your OTP is ${code}`;
  banner.classList.add('show');
  toast('New OTP generated', 'success');
});

document.getElementById('changeNumberBtn').addEventListener('click', () => showStep('phone'));
const tryAgainBtn = document.getElementById('tryAgainBtn');
if (tryAgainBtn) tryAgainBtn.addEventListener('click', () => showStep('phone'));

/* --- Step 3: new builder registration --- */
document.getElementById('newBuilderForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.getElementById('builderName').value.trim();
  const company = document.getElementById('builderCompany').value.trim();
  if (!name || !company) return;
  const result = registerBuilder({ name, company, phone: currentPhone });
  if (!result.ok) {
    toast(result.reason, 'error');
    return;
  }
  toast('Account created!', 'success');
  completeLogin(result.user);
});

function completeLogin(user) {
  setSession(user.id);
  toast(`Welcome, ${user.name.split(' ')[0]}`, 'success');
  setTimeout(() => {
    if (user.role === 'builder') window.location.href = 'builder.html';
    else if (user.role === 'supervisor') window.location.href = 'supervisor.html';
    else window.location.href = 'worker.html';
  }, 500);
}
