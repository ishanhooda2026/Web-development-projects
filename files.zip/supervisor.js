const supervisor = requireRole('supervisor');
renderUserChip(supervisor);
document.getElementById('todayDate').textContent = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' });

function render() {
  const projects = projectsForSupervisor(supervisor.id);

  if (!projects.length) {
    document.getElementById('noProjectState').classList.remove('hidden');
    document.getElementById('dashboardContent').classList.add('hidden');
    return;
  }

  document.getElementById('pageTitle').textContent = projects.length === 1 ? projects[0].name : 'My Sites';

  const workers = workersForSupervisor(supervisor.id);
  const presentIds = new Set(projects.flatMap(p => todaysAttendance(p.id)).map(a => a.userId));

  document.getElementById('statProjects').textContent = projects.length;
  document.getElementById('statWorkers').textContent = workers.length;
  document.getElementById('statPresent').textContent = presentIds.size;
  document.getElementById('statRate').textContent = workers.length ? Math.round((presentIds.size / workers.length) * 100) + '%' : '0%';

  document.getElementById('projectsList').innerHTML = projects.map(p => `
    <div class="project-row">
      <div style="flex:1">
        <div class="pname">${p.name}</div>
        <div class="text-muted" style="font-size:13px">${p.location} · ${workersForProject(p.id).length} labour assigned</div>
        <div class="progress-track"><div class="progress-fill" style="width:${p.progress}%"></div></div>
      </div>
      <div class="pct">${p.progress}%</div>
    </div>`).join('');

  const wList = document.getElementById('workersList');
  wList.innerHTML = workers.length ? workers.map(w => {
    const present = presentIds.has(w.id);
    const proj = projects.find(p => p.id === w.projectId);
    return `
    <div class="list-row">
      <div class="who">
        <div class="user-avatar">${initials(w.name)}</div>
        <div class="who-meta"><div class="n">${w.name}</div><div class="p">+91 ${w.phone} · ${w.trade} · ${proj ? proj.name : ''}</div></div>
      </div>
      <span class="badge ${present ? 'green' : 'gray'}">${present ? 'Present' : 'Not marked'}</span>
    </div>`;
  }).join('') : `<div class="empty-state"><div class="glyph">👷</div>No labour added yet.</div>`;

  const attList = document.getElementById('attendanceList');
  const todays = projects.flatMap(p => todaysAttendance(p.id).map(a => ({ ...a, projectName: p.name })));
  attList.innerHTML = todays.length ? todays.map(a => {
    const w = workers.find(u => u.id === a.userId);
    return `<div class="list-row"><div class="who"><div class="user-avatar">${initials(w?.name)}</div><div class="who-meta"><div class="n">${w?.name || 'Unknown'}</div><div class="p">${a.time} · ${a.projectName}</div></div></div><span class="badge green">In</span></div>`;
  }).join('') : `<div class="empty-state"><div class="glyph">✅</div>No check-ins yet today.</div>`;

  const select = document.getElementById('workerProject');
  select.innerHTML = projects.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
}
render();

document.getElementById('newWorkerForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.getElementById('workerName').value.trim();
  const phone = document.getElementById('workerPhone').value.trim();
  const trade = document.getElementById('workerTrade').value.trim();
  const projectId = document.getElementById('workerProject').value;
  const wageRate = parseInt(document.getElementById('workerWage').value, 10) || 700;
  if (!name || normalizePhone(phone).length !== 10) { toast('Enter a valid name and 10-digit phone number.', 'error'); return; }
  const result = addWorker({ name, phone, projectId, trade, wageRate, addedBy: supervisor.id });
  if (!result.ok) { toast(result.reason, 'error'); return; }
  closeModal('newWorkerModal');
  e.target.reset();
  toast(`${name} added`, 'success');
  render();
});
