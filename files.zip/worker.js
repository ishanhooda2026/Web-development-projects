const worker = requireRole('worker');
renderUserChip(worker);
document.getElementById('greetName').textContent = 'Hey, ' + worker.name.split(' ')[0];
document.getElementById('todayDate').textContent = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' });

function render() {
  const project = projectForWorker(worker);
  if (!project) {
    document.getElementById('noProjectState').classList.remove('hidden');
    document.getElementById('content').classList.add('hidden');
    return;
  }

  document.getElementById('projectInfo').innerHTML = `
    <div class="project-row">
      <div>
        <div class="pname">${project.name}</div>
        <div class="text-muted" style="font-size:13px">${project.location}</div>
        <div class="progress-track"><div class="progress-fill" style="width:${project.progress}%"></div></div>
      </div>
      <div class="pct">${project.progress}%</div>
    </div>`;

  document.getElementById('myInfo').innerHTML = `
    <div class="list-row"><div class="who-meta"><div class="n">Trade</div></div><span class="badge blue">${worker.trade}</span></div>
    <div class="list-row"><div class="who-meta"><div class="n">Daily wage</div></div><span class="badge green">₹${worker.wageRate}</span></div>
    <div class="list-row"><div class="who-meta"><div class="n">Phone</div></div><span class="text-secondary">+91 ${worker.phone}</span></div>`;

  const checkedIn = hasCheckedInToday(worker.id);
  const btn = document.getElementById('checkinBtn');
  const status = document.getElementById('checkinStatus');
  if (checkedIn) {
    btn.textContent = '✓ Checked In';
    btn.classList.add('done');
    btn.disabled = true;
    status.textContent = "You're marked present for today.";
  } else {
    btn.textContent = 'Check In';
    status.textContent = 'Tap to mark your attendance for today.';
  }
  return project;
}
let activeProject = render();

document.getElementById('checkinBtn').addEventListener('click', () => {
  if (!activeProject) return;
  checkIn(worker.id, activeProject.id);
  toast('Checked in for today', 'success');
  activeProject = render();
});
