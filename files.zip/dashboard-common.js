function initials(name) {
  return (name || '?').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
}

function openModal(id) {
  document.getElementById(id).classList.add('open');
}
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('modal-overlay')) e.target.classList.remove('open');
});

function renderUserChip(user) {
  const el = document.getElementById('userChip');
  if (!el) return;
  el.innerHTML = `
    <div class="user-avatar">${initials(user.name)}</div>
    <div class="user-meta">
      <div class="name">${user.name}</div>
      <div class="phone">+91 ${user.phone}</div>
    </div>`;
}
