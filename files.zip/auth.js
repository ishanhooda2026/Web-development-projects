/* ============================================================
   BuildSync AI — Auth & Data Layer
   Client-side persistence (localStorage) simulating a real
   phone+OTP identity system with a Builder -> Supervisor -> Worker
   hierarchy and per-project visibility.

   ── IMPORTANT: OTP DELIVERY ──────────────────────────────────
   There is no SMS gateway wired up (that needs a paid provider
   like MSG91/Twilio + a backend, which needs your own API keys).
   OTPs are generated for real and verified for real, but instead
   of being texted, they're shown on-screen in "Demo Mode" so the
   whole flow is fully testable end-to-end right now. Swap
   `sendOtp()` below for a real API call once you have a provider,
   nothing else in the app needs to change.
   ============================================================ */

const DB_KEY = 'buildsync_db_v1';
const SESSION_KEY = 'buildsync_session_v1';
const OTP_TTL_MS = 5 * 60 * 1000;

function seedDb() {
  return {
    users: [
      // Demo builder seeded so the flow is testable immediately.
      { id: 'u_builder_demo', role: 'builder', name: 'Jaydev Lamror', company: 'Lamror Constructions', phone: '9999900001', createdAt: Date.now(), createdBy: null }
    ],
    projects: [
      { id: 'p_demo1', name: 'Skyline Residency', location: 'Sector 12, Gurugram', builderId: 'u_builder_demo', progress: 70, labourCost: 360000, createdAt: Date.now() }
    ],
    attendance: [] // { id, userId, projectId, date, time, type: 'in'|'out' }
  };
}

function getDb() {
  const raw = localStorage.getItem(DB_KEY);
  if (!raw) {
    const seeded = seedDb();
    localStorage.setItem(DB_KEY, JSON.stringify(seeded));
    return seeded;
  }
  try { return JSON.parse(raw); } catch (e) { const s = seedDb(); localStorage.setItem(DB_KEY, JSON.stringify(s)); return s; }
}

function saveDb(db) { localStorage.setItem(DB_KEY, JSON.stringify(db)); }

function normalizePhone(phone) {
  return (phone || '').replace(/\D/g, '').slice(-10);
}

function findUserByPhone(phone) {
  const db = getDb();
  const p = normalizePhone(phone);
  return db.users.find(u => u.phone === p) || null;
}

/* ---------------- OTP ---------------- */

function otpStore() {
  const raw = sessionStorage.getItem('buildsync_otp_v1');
  return raw ? JSON.parse(raw) : {};
}
function saveOtpStore(s) { sessionStorage.setItem('buildsync_otp_v1', JSON.stringify(s)); }

function generateOtp(phone) {
  const code = Math.floor(1000 + Math.random() * 9000).toString();
  const store = otpStore();
  store[normalizePhone(phone)] = { code, expiresAt: Date.now() + OTP_TTL_MS, attempts: 0 };
  saveOtpStore(store);
  return code;
}

function verifyOtp(phone, code) {
  const store = otpStore();
  const entry = store[normalizePhone(phone)];
  if (!entry) return { ok: false, reason: 'No OTP requested for this number.' };
  if (Date.now() > entry.expiresAt) return { ok: false, reason: 'OTP expired. Request a new one.' };
  entry.attempts += 1;
  if (entry.attempts > 5) return { ok: false, reason: 'Too many attempts. Request a new OTP.' };
  saveOtpStore(store);
  if (entry.code !== code) return { ok: false, reason: 'Incorrect OTP.' };
  delete store[normalizePhone(phone)];
  saveOtpStore(store);
  return { ok: true };
}

/* ---------------- Session ---------------- */

function setSession(userId) { sessionStorage.setItem(SESSION_KEY, userId); }
function getSession() {
  const id = sessionStorage.getItem(SESSION_KEY);
  if (!id) return null;
  const db = getDb();
  return db.users.find(u => u.id === id) || null;
}
function logout() { sessionStorage.removeItem(SESSION_KEY); window.location.href = 'index.html'; }

function requireRole(role) {
  const user = getSession();
  if (!user || user.role !== role) {
    window.location.href = 'login.html';
    return null;
  }
  return user;
}

/* ---------------- Registration ---------------- */

function registerBuilder({ name, company, phone }) {
  const db = getDb();
  const p = normalizePhone(phone);
  if (db.users.find(u => u.phone === p)) return { ok: false, reason: 'This number is already registered.' };
  const user = { id: 'u_' + Date.now(), role: 'builder', name, company, phone: p, createdAt: Date.now(), createdBy: null };
  db.users.push(user);
  saveDb(db);
  return { ok: true, user };
}

function addSupervisor({ name, phone, projectIds, addedBy }) {
  const db = getDb();
  const p = normalizePhone(phone);
  let user = db.users.find(u => u.phone === p);
  if (user && user.role !== 'supervisor') return { ok: false, reason: 'This number is already registered as a ' + user.role + '.' };
  if (!user) {
    user = { id: 'u_' + Date.now() + Math.floor(Math.random()*999), role: 'supervisor', name, phone: p, projectIds: [], createdAt: Date.now(), createdBy: addedBy };
    db.users.push(user);
  }
  projectIds.forEach(pid => { if (!user.projectIds.includes(pid)) user.projectIds.push(pid); });
  saveDb(db);
  return { ok: true, user };
}

function addWorker({ name, phone, projectId, trade, wageRate, addedBy }) {
  const db = getDb();
  const p = normalizePhone(phone);
  let user = db.users.find(u => u.phone === p);
  if (user && user.role !== 'worker') return { ok: false, reason: 'This number is already registered as a ' + user.role + '.' };
  if (!user) {
    user = { id: 'u_' + Date.now() + Math.floor(Math.random()*999), role: 'worker', name, phone: p, projectId, trade: trade || 'General Labour', wageRate: wageRate || 700, createdAt: Date.now(), createdBy: addedBy };
    db.users.push(user);
  } else {
    user.projectId = projectId;
  }
  saveDb(db);
  return { ok: true, user };
}

function addProject({ name, location, builderId }) {
  const db = getDb();
  const project = { id: 'p_' + Date.now(), name, location, builderId, progress: 0, labourCost: 0, createdAt: Date.now() };
  db.projects.push(project);
  saveDb(db);
  return project;
}

/* ---------------- Queries ---------------- */

function projectsForBuilder(builderId) {
  return getDb().projects.filter(p => p.builderId === builderId);
}
function projectsForSupervisor(supervisorId) {
  const db = getDb();
  const sup = db.users.find(u => u.id === supervisorId);
  if (!sup) return [];
  return db.projects.filter(p => (sup.projectIds || []).includes(p.id));
}
function projectForWorker(worker) {
  const db = getDb();
  return db.projects.find(p => p.id === worker.projectId) || null;
}
function supervisorsForBuilder(builderId) {
  const projectIds = projectsForBuilder(builderId).map(p => p.id);
  return getDb().users.filter(u => u.role === 'supervisor' && (u.projectIds || []).some(pid => projectIds.includes(pid)));
}
function workersForProject(projectId) {
  return getDb().users.filter(u => u.role === 'worker' && u.projectId === projectId);
}
function workersForSupervisor(supervisorId) {
  const projectIds = (getDb().users.find(u => u.id === supervisorId)?.projectIds) || [];
  return getDb().users.filter(u => u.role === 'worker' && projectIds.includes(u.projectId));
}

function checkIn(userId, projectId) {
  const db = getDb();
  const now = new Date();
  db.attendance.push({
    id: 'a_' + Date.now(),
    userId, projectId,
    date: now.toISOString().slice(0, 10),
    time: now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
    type: 'in'
  });
  saveDb(db);
}

function todaysAttendance(projectId) {
  const today = new Date().toISOString().slice(0, 10);
  return getDb().attendance.filter(a => a.projectId === projectId && a.date === today);
}

function hasCheckedInToday(userId) {
  const today = new Date().toISOString().slice(0, 10);
  return getDb().attendance.some(a => a.userId === userId && a.date === today);
}
